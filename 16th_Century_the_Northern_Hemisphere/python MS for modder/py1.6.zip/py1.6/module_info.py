
# Point export_dir to the folder you will be keeping your module
# Make sure you use forward slashes (/) and NOT backward slashes (\)

#export_dir ="D:/Program Files (x86)/Mount&Blade Warband1.166/Modules/16th_py/"#for HolyAce
export_dir = "E:/16thTEST/"#for Yifeng and windmelodie

